
---

## 🐳 Docker Compose - Services définis

### 🔹 Service `db` (MySQL 5.7)

- Image : `mysql:5.7`
- Variables d’environnement :
  - `MYSQL_ROOT_PASSWORD=root`
  - `MYSQL_DATABASE=tpdb`
  - `MYSQL_USER=etudiant`
  - `MYSQL_PASSWORD=secret`
- Réseau : `backend`

### 🔹 Service `phpmyadmin`

- Image : `phpmyadmin/phpmyadmin`
- Accessible à : [http://localhost:8081](http://localhost:8081)
- Variable d’environnement :
  - `PMA_HOST=db`
- Réseau : `backend`

---

## ▶️ Lancement des services

```bash
docker-compose up -d
